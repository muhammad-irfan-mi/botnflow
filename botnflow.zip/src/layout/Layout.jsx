import React from 'react'

function Layout() {
  return (
    <div>
      
    </div>
  )
}

export default Layout
